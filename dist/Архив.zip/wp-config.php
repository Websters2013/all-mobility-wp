<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'all_about_mobility');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '1111');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'e1`25{AezK/j-FnY:]Bw^4Z.@SG;a#)x; 7GbY#gb5#EwzSB+u1V!^-P32SSFPOj');
define('SECURE_AUTH_KEY',  'i[krKNGo&n}-BzGUy@ Bg|;3pNxWdb;ZaS3X&N%kEzh~}Z}C#w*XJ&N8A-*GRq}A');
define('LOGGED_IN_KEY',    'c0B0](oqr8h_F9 lvK2*#9&L(b5H>7s,06|tK5B$^!d2><x4`b(*&p.Dx/T3=y$R');
define('NONCE_KEY',        'WE:<=e$C-`@,R`p U;j}|Gbf$f?f)yi$Pd.C2]zw&[`2(Ghficvjb`Oa)$bG@8F*');
define('AUTH_SALT',        't+(KGW*uJKZ3hTsnet=OW~mSleP $+lWNj17CZ*>4z39`$ 9w<EvX%LcA*KvQ{,~');
define('SECURE_AUTH_SALT', 'RT=aFTz:(<oBY1Q`p.OQ IcIq_H9N5)0O8w7GFfEie@78~JUyr>AmytqKevnU0,4');
define('LOGGED_IN_SALT',   '0lbO}]CzXi}53y6;JDbg-*|Pt`OA: *J^wne[+}E_q},q=K/-Y@<AvnRyd:.4,kU');
define('NONCE_SALT',       ']U!&~{it4&rm AGO{CmVXMzH>!g//aRF?Ky3zftsRd;;!aeruc<*BH<g2QHogvo=');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'am_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
